var express = require('express');
var bodyParser = require("body-parser");
var app = express();
var mysql = require('mysql');

var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Dennis1111",
  database: 'sample'
});
//Establish MySQL connection
connection.connect(function(err) {
    if (err) 
       throw err
    else {
        console.log('Connected to MySQL');
    }
 });
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); 

 app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});


//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// for the apy
app.get('/list', function (req, res,next) {
    debugger;
    connection.query('SELECT * FROM bank_details', function(err,result) {
       debugger;
       console.log(result);
       res.send(JSON.stringify(result));
   });
 })
 app.post('/addnew', function (req, res,next) {
    var name = req.body.name;
    var formula = req.body.formula;
    var values = [];
    values.push([name,formula]);
    connection.query('INSERT INTO bank_details (name,formula) VALUES ?', [values], function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/del_item', function (req, res) {
    var query = "DELETE FROM bank_details WHERE id=" + req.body.id;
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/updateItem', function (req, res,next) {
    var query = "UPDATE bank_details SET name = '" + req.body.name + "',formula = '" + req.body.formula + "' where id =" + req.body.id;
    console.log(query);
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })



//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// for the product
app.get('/productlist', function (req, res,next) {
    debugger;
    connection.query('SELECT * FROM product', function(err,result) {
       debugger;
       console.log(result);
       res.send(JSON.stringify(result));
   });
 })
 app.post('/productaddnew', function (req, res,next) {
    var productname = req.body.productname;
    var status = req.body.status;
    var values = [];
    values.push([productname,status]);
    connection.query('INSERT INTO product (productname,status) VALUES ?', [values], function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })

 app.post('/productdelItem', function (req, res) {
    var query = "DELETE FROM product WHERE id=" + req.body.id;
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })


 app.post('/productupdateItem', function (req, res,next) {
    var query = "UPDATE product SET productname = '" + req.body.productname + "',status = '" + req.body.status + "' where id =" + req.body.id;
    console.log(query);
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 



//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// for ProductGroup
app.get('/productgrouplist', function (req, res,next) {
    debugger;
    connection.query('SELECT * FROM productgroup', function(err,result) {
       debugger;
       console.log(result);
       res.send(JSON.stringify(result));
   });
 })
 app.post('/productgroupaddnew', function (req, res,next) {
    var productgroupname = req.body.productgroupname;
    var product = req.body.product;
    var values = [];
    values.push([productgroupname,product]);
    connection.query('INSERT INTO productgroup (productgroupname,product) VALUES ?', [values], function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/productgroupdelItem', function (req, res) {
    var query = "DELETE FROM productgroup WHERE id=" + req.body.id;
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/productgroupupdateItem', function (req, res,next) {
    var query = "UPDATE productgroup SET productgroupname = '" + req.body.productgroupname + "',product = '" + req.body.product + "' where id =" + req.body.id;
    console.log(query);
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })

 
//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// for productheader
app.get('/productheaderlist', function (req, res,next) {
    debugger;
    connection.query('SELECT * FROM productheader', function(err,result) {
       debugger;
       console.log(result);
       res.send(JSON.stringify(result));
   });
 })
 app.post('/productheaderaddnew', function (req, res,next) {
    var productheadername = req.body.productheadername;
    var status = req.body.status;
    var values = [];
    values.push([productheadername,formula]);
    connection.query('INSERT INTO productheader (productheadername,status) VALUES ?', [values], function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/productheaderdelItem', function (req, res) {
    var query = "DELETE FROM productheader WHERE id=" + req.body.id;
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/productheaderupdateItem', function (req, res,next) {
    var query = "UPDATE productheader SET productheadername = '" + req.body.productheadername + "',status = '" + req.body.status + "' where id =" + req.body.id;
    console.log(query);
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })

 

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// for the productKeyregion
app.get('/productkeyregionlist', function (req, res,next) {
    debugger;
    connection.query('SELECT * FROM productKeyregion', function(err,result) {
       debugger;
       console.log(result);
       res.send(JSON.stringify(result));
   });
 })
 app.post('/productkeyregionaddnew', function (req, res,next) {
    var productKeyregion = req.body.productKeyregion;
    var productkey = req.body.productkey;
    var values = [];
    values.push([name,formula]);
    connection.query('INSERT INTO productKeyregion (productKeyregion,formula) VALUES ?', [values], function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/productkeyregiondelItem', function (req, res) {
    var query = "DELETE FROM productKeyregion WHERE id=" + req.body.id;
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/productkeyregionupdateItem', function (req, res,next) {
    var query = "UPDATE productKeyregion SET productKeyregion = '" + req.body.productKeyregion + "',productkey = '" + req.body.productkey + "' where id =" + req.body.id;
    console.log(query);
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// for the ratesheet
 app.get('/ratesheetlist', function (req, res,next) {
     debugger;
     connection.query('SELECT * FROM ratesheet', function(err,result) {
        debugger;
        console.log(result);
        res.send(JSON.stringify(result));
    });
  })
  app.post('/ratesheetaddnew', function (req, res,next) {
     var ratesheetname = req.body.ratesheetname;
     var description = req.body.description;
     var status = req.body.status;
     var values = [];
     values.push([ratesheetname,description,status]);
     connection.query('INSERT INTO ratesheet (ratesheetname,description,status) VALUES ?', [values], function(err,result) {
         if(err) {
             res.send(JSON.stringify('Error'));
         } else {
             res.send(JSON.stringify('Success'));
         }
     });
  })
  app.post('/ratesheetdelItem', function (req, res) {
     var query = "DELETE FROM ratesheet WHERE id=" + req.body.id;
     connection.query(query, function(err,result) {
         if(err) {
             res.send(JSON.stringify('Error'));
         } else {
             res.send(JSON.stringify('Success'));
         }
     });
  })
  app.post('/ratesheetupdateItem', function (req, res,next) {
     var query = "UPDATE ratesheet SET ratesheetname = '" + req.body.ratesheetname + "',status = '" + req.body.status +"',description = '" + req.body.description + "' where id =" + req.body.id;
     console.log(query);
     connection.query(query, function(err,result) {
         if(err) {
             res.send(JSON.stringify('Error'));
         } else {
             res.send(JSON.stringify('Success'));
         }
     });
  })




//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// for the region
app.get('/regionlist', function (req, res,next) {
    debugger;
    connection.query('SELECT * FROM region', function(err,result) {
       debugger;
       console.log(result);
       res.send(JSON.stringify(result));
   });
 })
 app.post('/regionaddnew', function (req, res,next) {
    var state = req.body.state;
    var regioncode = req.body.regioncode;
    var values = [];
    values.push([state,regioncode]);
    connection.query('INSERT INTO region (state,regioncode) VALUES ?', [values], function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/regiondelItem', function (req, res) {
    var query = "DELETE FROM region WHERE id=" + req.body.id;
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/regionupdateItem', function (req, res,next) {
    var query = "UPDATE region SET state = '" + req.body.state + "',regioncode = '" + req.body.regioncode + "' where id =" + req.body.id;
    console.log(query);
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })






 //----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// for the user
app.get('/userlist', function (req, res,next) {
    debugger;
    connection.query('SELECT * FROM user', function(err,result) {
       debugger;
       console.log(result);
       res.send(JSON.stringify(result));
   });
 })
 app.post('/useraddnew', function (req, res,next) {
    var firstname = req.body.firstname;
    var lastname = req.body.lastname;
    var values = [];
    values.push([firstname,lastname]);
    connection.query('INSERT INTO user (firstname,lastname) VALUES ?', [values], function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/userdelItem', function (req, res) {
    var query = "DELETE FROM user WHERE id=" + req.body.id;
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/userupdateItem', function (req, res,next) {
    var query = "UPDATE user SET firstname = '" + req.body.firstname + "',lastname = '" + req.body.lastname + "' where id =" + req.body.id;
    console.log(query);
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })


 


//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// for the group
app.get('/grouplist', function (req, res,next) {
    debugger;
    connection.query('SELECT * FROM group', function(err,result) {
       debugger;
       console.log(result);
       res.send(JSON.stringify(result));
   });
 })
 app.post('/groupaddnew', function (req, res,next) {
    var groupname = req.body.groupname;
    var status = req.body.status;
    var values = [];
    values.push([groupname,status]);
    connection.query('INSERT INTO group (groupname,status) VALUES ?', [values], function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/groupdelItem', function (req, res) {
    var query = "DELETE FROM group WHERE id=" + req.body.id;
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })
 app.post('/groupupdateItem', function (req, res,next) {
    var query = "UPDATE group SET groupname = '" + req.body.groupname + "',status = '" + req.body.status + "' where id =" + req.body.id;
    console.log(query);
    connection.query(query, function(err,result) {
        if(err) {
            res.send(JSON.stringify('Error'));
        } else {
            res.send(JSON.stringify('Success'));
        }
    });
 })



//--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
app.use(express.static('public'));

app.get('/index.htm', function (req, res) {
    res.sendFile( __dirname + "/" + "index.htm" );
 })
 
 app.get('/process_get', function (req, res) {
    // Prepare output in JSON format
    response = {
       first_name:req.query.first_name,
       last_name:req.query.last_name
    };
    console.log(response);
    res.end(JSON.stringify(response));
 })

// This responds with "Hello World" on the homepage
app.get('/', function (req, res) {
   console.log("Got a GET request for the homepage");
   res.send('Hello GET');
})

// This responds a POST request for the homepage
app.post('/', function (req, res) {
   console.log("Got a POST request for the homepage");
   res.send('Hello POST');
})

// This responds a DELETE request for the /del_user page.
app.delete('/del_user', function (req, res) {
   console.log("Got a DELETE request for /del_user");
   res.send('Hello DELETE');
})

// This responds a GET request for the /list_user page.


// This responds a GET request for abcd, abxcd, ab123cd, and so on
app.get('/ab*cd', function(req, res) {   
   console.log("Got a GET request for /ab*cd");
   res.send('Page Pattern Match');
})

var server = app.listen(8081, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})