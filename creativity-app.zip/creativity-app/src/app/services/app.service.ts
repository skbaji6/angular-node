import { Injectable } from '@angular/core';
import { HttpClient, HttpParams} from '@angular/common/http'
import { Observable} from 'rxjs/Observable'
import { RequestOptions } from '@angular/http';
@Injectable()
export class AppService {

  constructor(private http: HttpClient) { 

  }
 getGridList() : Observable<any[]> {

    return this.http.get<any[]>('http://localhost:8081/list');
 }
postNewItem(body) {
  return this.http.post<any>('http://localhost:8081/addnew',body);
}
postUpdateItem(body) {
  return this.http.post<any>('http://localhost:8081/updateItem',body);
}
deleteItem(body) {
  return this.http.post<any>('http://localhost:8081/del_item',body);
}

// //region
// getRegionGridList() : Observable<any[]> {

//   return this.http.get<any[]>('http://localhost:8081/regionlist');
// }
// postNewRegionItem(body) {
// return this.http.post<any>('http://localhost:8081/regionaddnew',body);
// }
// postUpdateRegionItem(body) {
// return this.http.post<any>('http://localhost:8081/regionupdateItem',body);
// }
// deleteRegionItem(body) {
// return this.http.post<any>('http://localhost:8081/regiondelItem',body);
// }




// //getproductGridList
// getProductGridList() : Observable<any[]> {

//   return this.http.get<any[]>('http://localhost:8081/productlist');
// }
// postNewProductItem(body) {
// return this.http.post<any>('http://localhost:8081/productaddnew',body);
// }
// postUpdateProductItem(body) {
// return this.http.post<any>('http://localhost:8081/productupdateItem',body);
// }
// deleteProductItem(body) {
// return this.http.post<any>('http://localhost:8081/productdelItem',body);
// }


// //getUserGridList
// getUserGridList() : Observable<any[]> {

//   return this.http.get<any[]>('http://localhost:8081/userlist');
// }
// postUserNewItem(body) {
// return this.http.post<any>('http://localhost:8081/useraddnew',body);
// }
// postUserUpdateItem(body) {
// return this.http.post<any>('http://localhost:8081/userupdateItem',body);
// }
// deleteUserItem(body) {
// return this.http.post<any>('http://localhost:8081/userdelItem',body);
// }


// //getGroupGridList
// getGroupGridList() : Observable<any[]> {

//   return this.http.get<any[]>('http://localhost:8081/grouplist');
// }
// postGroupNewItem(body) {
// return this.http.post<any>('http://localhost:8081/groupaddnew',body);
// }
// postGroupUpdateItem(body) {
// return this.http.post<any>('http://localhost:8081/groupupdateItem',body);
// }
// deleteGroupItem(body) {
// return this.http.post<any>('http://localhost:8081/groupdelItem',body);
// }


// //getProductHeaderGridList
// getProductHeaderGridList() : Observable<any[]> {

//   return this.http.get<any[]>('http://localhost:8081/productheaderlist');
// }
// postProductHeaderNewItem(body) {
// return this.http.post<any>('http://localhost:8081/productheaderaddnew',body);
// }
// postProductHeaderUpdateItem(body) {
// return this.http.post<any>('http://localhost:8081/productheaderupdateItem',body);
// }
// deleteProductHeaderItem(body) {
// return this.http.post<any>('http://localhost:8081/productheaderdelItem',body);
// }


// //getProductGroupGridList
// getProductGroupGridList() : Observable<any[]> {

//   return this.http.get<any[]>('http://localhost:8081/productgrouplist');
// }
// postProductGroupNewItem(body) {
// return this.http.post<any>('http://localhost:8081/productgroupaddnew',body);
// }
// postProductGroupUpdateItem(body) {
// return this.http.post<any>('http://localhost:8081/productgroupupdateItem',body);
// }
// deleteProductGroupItem(body) {
// return this.http.post<any>('http://localhost:8081/productgroupdelItem',body);
// }


// //getProductKeyRegionGridList
// getProductKeyRegionGridList() : Observable<any[]> {

//   return this.http.get<any[]>('http://localhost:8081/productkeyregionlist');
// }
// postProductKeyRegionNewItem(body) {
// return this.http.post<any>('http://localhost:8081/productkeyregionaddnew',body);
// }
// postProductKeyRegionUpdateItem(body) {
// return this.http.post<any>('http://localhost:8081/productkeyregionupdateItem',body);
// }
// deleteProductKeyRegionItem(body) {
// return this.http.post<any>('http://localhost:8081/productkeyregiondelItem',body);
// }

// //getRateSheetGridList
// getRateSheetGridList() : Observable<any[]> {


//   return this.http.get<any[]>('http://localhost:8081/ratesheetlist');
// }
// postRateSheetNewItem(body) {
// return this.http.post<any>('http://localhost:8081/ratesheetaddnew',body);
// }
// postRateSheetUpdateItem(body) {
// return this.http.post<any>('http://localhost:8081/ratesheetupdateItem',body);
// }
// deleteRateSheetItem(body) {
// return this.http.post<any>('http://localhost:8081/ratesheetdelItem',body);
// }

}
