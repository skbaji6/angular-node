import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppService } from './services/app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  showGrid = false;
  regionGrid = false;
  productGrid = false;
  userGrid = false;
  groupGrid = false;
  productHeaderGrid = false;
  productGroupGrid = false;
  productKeyRegionGrid = false;
  rateSheetGrid = false;
  isGridVisible = true;
  isregionGridVisible = true;
  isproductGridVisible = true;
  isuserGridVisible = true;
  isgroupGridVisible = true;
  isproductHeaderGridVisible = true;
  isproductGroupGridVisible = true;
  isproductKeyRegionGridVisible = true;
  israteSheetGridVisible = true;
  

  name;
  formula;
  status;
  state;
  regioncode;
  productname;
  firstname;
  lastname;
  groupname;
  productheadername;
  productgroupname;
  product;
  ratesheetname;
  description;
  productKeyregion;
  productkey;
  selectedObject;
  data = [];
  isEditFlow = false;
  isProductEditFlow = false;
  isUserEditFlow = false;
  isGroupEditFlow = false;
  isProductHeaderEditFlow = false;
  isProductGroupEditFlow = false;
  isProductKeyRegionEditFlow = false;
  isRateSheetEditFlow = false;
  isRegionEditFlow = false;


   
   constructor(private appService:AppService){

   }
   ngOnInit(): void {
     this.loadGridList();
    //  this.loadGroupGridList();
    //  this.loadProductGridList();
    //  this.loadProductGroupGridList();
    //  this.loadProductHeaderGridList();
    //  this.loadProductKeyRegionGridList();
    //  this.loadRateSheetGridList();
    //  this.loadUserGridList();
    //  this.loadRegionGridList();
  }


  //-------------------------------------------------//-------------------------------------------------//-------------------------------------------------//-------------------------------------------------
  loadGridList() {
    this.appService.getGridList().subscribe(results => {
      this.data = results;
    }, (error) => {
      console.log('error occurred');
    });
  }


  // loadProductGridList(){
  //   this.appService.getProductGridList().subscribe(results => {
  //     this.data = results;
  //   }, (error) => {
  //     console.log('error occurred');
  //   });
  // }

  // loadRegionGridList(){
  //   this.appService.getRegionGridList().subscribe(results => {
  //     this.data = results;
  //   }, (error) => {
  //     console.log('error occurred');
  //   });

  // }

  // loadUserGridList(){
  //   this.appService.getUserGridList().subscribe(results => {
  //     this.data = results;
  //   }, (error) => {
  //     console.log('error occurred');
  //   });
  // }
  // loadGroupGridList(){
  //   this.appService.getGroupGridList().subscribe(results => {
  //     this.data = results;
  //   }, (error) => {
  //     console.log('error occurred');
  //   });
  // }
  // loadProductHeaderGridList(){
  //   this.appService.getProductHeaderGridList().subscribe(results => {
  //     this.data = results;
  //   }, (error) => {
  //     console.log('error occurred');
  //   });
  // }
  // loadProductGroupGridList(){
  //   this.appService.getProductGroupGridList().subscribe(results => {
  //     this.data = results;
  //   }, (error) => {
  //     console.log('error occurred');
  //   });
  // }
  // loadProductKeyRegionGridList(){
  //   this.appService.getProductKeyRegionGridList().subscribe(results => {
  //     this.data = results;
  //   }, (error) => {
  //     console.log('error occurred');
  //   });
  // }

  // loadRateSheetGridList(){
  //   this.appService.getRateSheetGridList().subscribe(results => {
  //     this.data = results;
  //   }, (error) => {
  //     console.log('error occurred');
  //   });
  // }

//-------------------------------------------------//-------------------------------------------------//-------------------------------------------------//-------------------------------------------------
   onFilterMenuSelection() {
     this.showGrid = true;

   } 

  //  onFilterRegionSelection(){
  //     this.regionGrid = true;

  //  }

  //  onFilterProductSelection(){
  //    this.productGrid = true;
  //  }
  //  onFilterUserSelection() {
  //   this.userGrid = true;
  //  }
  //  onFilterGroupSelection(){
  //   this.groupGrid = true;
  //  }
  //  onFilterRateSheetSelection(){
  //   this.rateSheetGrid = true;
  //  }
  //  onFilterProductKeyRegionSelection(){
  //   this.productKeyRegionGrid = true;
  //  }
  //  onFilterProductGroupSelection(){
  //   this.productGroupGrid = true;
  //  }
  //  onFilterProductHeaderSelection(){
  //   this.productHeaderGrid = true;
  //  }






  //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

   onNew() {
     this.isEditFlow = false;
     this.isGridVisible = false;
   }


  //  onNewRegion(){
  //     this.isRegionEditFlow = false;
  //     this.isregionGridVisible = false;
  //  }

  //  onNewProduct(){
  //     this.isProductEditFlow = false;
  //     this.isproductGridVisible = false;
  //  }

  //  onNewUser(){
  //   this.isUserEditFlow = false;
  //   this.isuserGridVisible = false;
  //  }


  //  onNewGroup(){
  //   this.isGroupEditFlow = false;
  //   this.isgroupGridVisible = false;
  //  }

  //  onNewProductHeader(){ 
  //   this.isProductHeaderEditFlow = false;
  //   this.isproductHeaderGridVisible = false;

  //  }

  //  onNewProductGroup(){
  //   this.isProductGroupEditFlow = false;
  //   this.isproductGroupGridVisible = false;
  //  }

  //  onNewProductKeyRegion(){
  //   this.isProductKeyRegionEditFlow = false;
  //   this.isproductKeyRegionGridVisible = false;
  //  }

  //  onNewRateSheet(){
  //   this.israteSheetGridVisible = false;
  //   this.isRateSheetEditFlow = false;
  //  }


   //--------------------------------------------------------------------------------------------------------------------------------------

   onSave(){
    if(this.name != undefined && this.formula != undefined){
      if(this.isEditFlow) {
        let body = {
          "id" : this.selectedObject.id,
          "name" : this.name,
          "formula" : this.formula
        };
        this.appService.postUpdateItem(body).subscribe(results => {
          debugger;
          console.log(results);
          this.loadGridList();
        }, (error) => {
          debugger;
          console.log('error occurred');
        });
      } else {
        let body = {
          "name" : this.name,
          "formula" : this.formula
        };
        this.appService.postNewItem(body).subscribe(results => {
          debugger;
          console.log(results);
          this.loadGridList();
        }, (error) => {
          debugger;
          console.log('error occurred');
        });
      }
      this.isGridVisible = true;
    }
  } 


  //  onSaveProduct(){
  //   if(this.productname != undefined && this.status != undefined){
  //     if(this.isProductEditFlow) {
  //       let body = {
  //         "productid" : this.selectedObject.productid,
  //         "productname" : this.productname,
  //         "status" : this.status
  //       };
  //       this.appService.postUpdateItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadProductGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     } else {
  //       let body = {
  //         "productname" : this.productname,
  //         "status" : this.status
  //       };
  //       this.appService.postNewItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     }
  //     this.isproductGridVisible = true;
  //   }
  //  } 


   
   


  //  onSaveRegion(){
  //   if(this.state != undefined && this.regioncode != undefined){
  //     if(this.isRegionEditFlow) {
  //       let body = {
  //         "regionid" : this.selectedObject.regionid,
  //         "state" : this.state,
  //         "regioncode" : this.regioncode
  //       };
  //       this.appService.postUpdateItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadRegionGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     } else {
  //       let body = {
  //         "state" : this.state,
  //         "regioncode" : this.regioncode
  //       };
  //       this.appService.postNewItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadRegionGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     }
  //     this.isregionGridVisible = true;
  //   }
  //  } 



   
   

  //  onSaveGroup(){
  //   if(this.groupname != undefined && this.status != undefined){
  //     if(this.isGroupEditFlow) {
  //       let body = {
  //         "groupid" : this.selectedObject.groupid,
  //         "groupname" : this.groupname,
  //         "status" : this.status
  //       };
  //       this.appService.postUpdateItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadGroupGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     } else {
  //       let body = {
  //         "groupname" : this.groupname,
  //         "status" : this.status
  //       };
  //       this.appService.postNewItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadGroupGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     }
  //     this.isgroupGridVisible = true;
  //   }
  //  } 

   

   
   

  //  onSaveProductKeyRegion(){
  //   if(this.name != undefined && this.formula != undefined){
  //     if(this.isProductKeyRegionEditFlow) {
  //       let body = {
  //         "productKeyregionid" : this.selectedObject.productKeyregionid,
  //         "productKeyregion" : this.productKeyregion,
  //         "productkey" : this.productkey
  //       };
  //       this.appService.postUpdateItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadProductKeyRegionGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     } else {
  //       let body = {
  //         "productKeyregion" : this.productKeyregion,
  //         "productkey" : this.productkey
  //       };
  //       this.appService.postNewItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadProductKeyRegionGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     }
  //     this.isproductKeyRegionGridVisible = true;
  //   }
  //  } 

   
   
   
   

  //  onSaveRateSheet(){
  //   if(this.ratesheetname != undefined && this.description != undefined && this.status != undefined){
  //     if(this.isRateSheetEditFlow) {
  //       let body = {
  //         "ratesheetid" : this.selectedObject.ratesheetid,
  //         "ratesheetname" : this.ratesheetname,
  //         "description" : this.description,
  //         "status" : this.status
  //       };
  //       this.appService.postUpdateItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadRateSheetGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     } else {
  //       let body = {
  //         "ratesheetname" : this.ratesheetname,
  //         "description" : this.description,
  //         "status" : this.status
  //       };
  //       this.appService.postNewItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadRateSheetGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     }
  //     this.israteSheetGridVisible = true;
  //   }
  //  }    



   
   
   
  //  onSaveUser(){
  //   if(this.firstname != undefined && this.lastname != undefined){
  //     if(this.isUserEditFlow) {
  //       let body = {
  //         "userid" : this.selectedObject.userid,
  //         "firstname" : this.firstname,
  //         "lastname" : this.lastname
  //       };
  //       this.appService.postUpdateItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadUserGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     } else {
  //       let body = {
  //         "firstname" : this.firstname,
  //         "lastname" : this.lastname
  //       };
  //       this.appService.postNewItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadUserGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     }
  //     this.isuserGridVisible = true;
  //   }
  //  } 



   
   

  //  onSaveproductHeader(){
  //   if(this.productheadername != undefined && this.status != undefined){
  //     if(this.isProductHeaderEditFlow) {
  //       let body = {
  //         "productheaderid" : this.selectedObject.productheaderid,
  //         "productheadername" : this.productheadername,
  //         "status" : this.status
  //       };
  //       this.appService.postUpdateItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadProductHeaderGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     } else {
  //       let body = {
  //         "productheadername" : this.productheadername,
  //         "status" : this.status
  //       };
  //       this.appService.postNewItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadProductHeaderGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     }
  //     this.isproductHeaderGridVisible = true;
  //   }
  //  }    



   
   
  //  onSaveProductGroup(){
  //   if(this.productgroupname != undefined && this.product != undefined){
  //     if(this.isProductGroupEditFlow) {
  //       let body = {
  //         "productgroupid" : this.selectedObject.productgroupid,
  //         "productgroupname" : this.productgroupname,
  //         "product" : this.product
  //       };
  //       this.appService.postUpdateItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadProductGroupGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     } else {
  //       let body = {
  //         "productgroupname" : this.productgroupname,
  //         "product" : this.product
  //       };
  //       this.appService.postNewItem(body).subscribe(results => {
  //         debugger;
  //         console.log(results);
  //         this.loadProductGroupGridList();
  //       }, (error) => {
  //         debugger;
  //         console.log('error occurred');
  //       });
  //     }
  //     this.isproductGroupGridVisible = true;
  //   }
  //  } 



//----------------------------------------------------------------------------------//----------------------------------------------------------------------------------//----------------------------------------------------------------------------------

   onRowSelection(index, row) {
    for (let i = 0; i < this.data.length; i++) {
      if (index == i) {
        this.data[i].selected = true;
        this.selectedObject = row;
      } else {
        this.data[i].selected = false;
      }
    }
  }


  //--------------------------------------------------------------------------------------------------------------------------------------
  onEdit() {
    this.isGridVisible = false;
    this.isEditFlow = true;
    this.name = this.selectedObject.name;
    this.formula = this.selectedObject.formula;
  }  

  //  onEditProduct() {
  //   this.isproductGridVisible = false;
  //   this.isProductEditFlow = true;
  //   this.productname = this.selectedObject.productname;
  //   this.status = this.selectedObject.status;
  // }

  

  // onEditUser() {
  //   this.isuserGridVisible = false;
  //   this.isUserEditFlow = true;
  //   this.firstname = this.selectedObject.firstname;
  //   this.lastname = this.selectedObject.lastname;
  // }


  // onEditGroup() {
  //   this.isgroupGridVisible = false;
  //   this.isGroupEditFlow = true;
  //   this.groupname = this.selectedObject.groupname;
  //   this.status = this.selectedObject.status;
  // }


  // onEditProductHeader() {
  //   this.isproductHeaderGridVisible = false;
  //   this.isProductHeaderEditFlow = true;
  //   this.productheadername = this.selectedObject.productheadername;
  //   this.status = this.selectedObject.status;
  // }


  // onEditProductGroup() {
  //   this.isproductGroupGridVisible = false;
  //   this.isProductGroupEditFlow = true;
  //   this.productgroupname = this.selectedObject.productgroupname;
  //   this.product = this.selectedObject.product;
  // }


  // onEditProductKeyRegion() {
  //   this.isproductKeyRegionGridVisible = false;
  //   this.isProductKeyRegionEditFlow = true;
  //   this.productKeyregion = this.selectedObject.productKeyregion;
  //   this.productkey = this.selectedObject.productkey;
  // }


  // onEditRateSheet() {
  //   this.israteSheetGridVisible = false;
  //   this.isRateSheetEditFlow = true;
  //   this.ratesheetname = this.selectedObject.ratesheetname;
  //   this.description = this.selectedObject.description;
  //   this.status = this.selectedObject.status;
  // }


  // onEditRegion() {
  //   this.isregionGridVisible = false;
  //   this.isRegionEditFlow = true;
  //   this.state = this.selectedObject.state;
  //   this.regioncode = this.selectedObject.regioncode;
  // }



  //--------------------------------------------------------------------------------------------------------------------------------------
  onDelete() {
    let body = {
      "id" : this.selectedObject.id
    };
    this.appService.deleteItem(body).subscribe(results => {
      debugger;
      console.log(results);
      this.loadGridList();
    }, (error) => {
      debugger;
      console.log('error occurred');
    });
  }   
  
//   onDeleteRegion() {
//     let body = {
//       "regionid" : this.selectedObject.regionid
//     };
//     this.appService.deleteItem(body).subscribe(results => {
//       debugger;
//       console.log(results);
//       this.loadRegionGridList();
//     }, (error) => {
//       debugger;
//       console.log('error occurred');
//     });
//   }  


//   onDeleteProduct() {
//     let body = {
//       "productid" : this.selectedObject.productid
//     };
//     this.appService.deleteItem(body).subscribe(results => {
//       debugger;
//       console.log(results);
//       this.loadProductGridList();
//     }, (error) => {
//       debugger;
//       console.log('error occurred');
//     });
//   }  

//   onDeleteUser() {
//     let body = {
//       "userid" : this.selectedObject.userid
//     };
//     this.appService.deleteItem(body).subscribe(results => {
//       debugger;
//       console.log(results);
//       this.loadUserGridList();
//     }, (error) => {
//       debugger;
//       console.log('error occurred');
//     });
//   }  



//   onDeleteGroup() {
//     let body = {
//       "groupid" : this.selectedObject.groupid
//     };
//     this.appService.deleteItem(body).subscribe(results => {
//       debugger;
//       console.log(results);
//       this.loadGroupGridList();
//     }, (error) => {
//       debugger;
//       console.log('error occurred');
//     });
//   }  



//   onDeleteProductHeader() {
//     let body = {
//       "productheaderid" : this.selectedObject.productheaderid
//     };
//     this.appService.deleteItem(body).subscribe(results => {
//       debugger;
//       console.log(results);
//       this.loadProductHeaderGridList();
//     }, (error) => {
//       debugger;
//       console.log('error occurred');
//     });
//   }   
  
  
//   onDeleteProductGroup() {
//     let body = {
//       "productgroupid" : this.selectedObject.productgroupid
//     };
//     this.appService.deleteItem(body).subscribe(results => {
//       debugger;
//       console.log(results);
//       this.loadProductGroupGridList();
//     }, (error) => {
//       debugger;
//       console.log('error occurred');
//     });
//   } 


//   onDeleteProductKeyRegion() {
//     let body = {
//       "productkeyregionid" : this.selectedObject.productkeyregionid
//     };
//     this.appService.deleteItem(body).subscribe(results => {
//       debugger;
//       console.log(results);
//       this.loadProductKeyRegionGridList();
//     }, (error) => {
//       debugger;
//       console.log('error occurred');
//     });
//   } 
  
  

//   onDeleteRateSheet() {
//     let body = {
//       "ratesheetid" : this.selectedObject.ratesheetid
//     };
//     this.appService.deleteItem(body).subscribe(results => {
//       debugger;
//       console.log(results);
//       this.loadRateSheetGridList();
//     }, (error) => {
//       debugger;
//       console.log('error occurred');
//     });
//   } 
  
 }
//--------------------------------------------------------------------------------------------------------------------------------------